-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2016 at 07:56 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `productdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE IF NOT EXISTS `about_us` (
`id` int(11) NOT NULL,
  `mobile` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `mobile`, `email`, `address`, `description`) VALUES
(1, 123456789, 'minhaz@yahoo.com', 'dhaka 1229, niketon, gulshan , dhaka.', '"Sadakalo Films" is a private production house in Bangladesh. Started on 11.11.15.\r\nOur 1st & final destination is movie & entertainment.\r\nOur caption- Think Different...Be Different...\r\nSo stay with us for your best satisfaction in your everyday life & thank you to all.\r\nCorporate Office-\r\nRoad-15,House-41(3rd floor) Nikunja-2,Khilkhet,Dhaka-1229.\r\nOur Official Youtube channel\r\nOur Official Facebook Page\r\nOur Official Twitter\r\nGoogle+\r\nContact-\r\n01625894580, 01824300064\r\nEmail- sadakalofilms.bd@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`id` int(11) NOT NULL,
  `address` varchar(400) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `about_us` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `address`, `phone`, `email`, `about_us`) VALUES
(1, '123, New york lane. ', 1700000001, 'abcdef@gmail.com', '"Sadakalo Films" is a private production house in Bangladesh. Started on 11.11.15. Our 1st & final destination is movie & entertainment. Our caption- Think Different...Be Different... So stay with us for your best satisfaction in your everyday life & thank you to all. Corporate Office- Road-15,House-41(3rd floor) Nikunja-2,Khilkhet,Dhaka-1229. Our Official Youtube channel Our Official Facebook Page Our Official Twitter Google+');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
`id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `category` varchar(250) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(2) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=117 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `title`, `category`, `picture`, `description`, `status`) VALUES
(110, 'samsung', 'mobile', '340057b7ecce21224avast-mobile-security-1.png', 'This is a new samsung mobile.', '0'),
(111, 'samsung', 'mobile', '1097857b7ef227422eavast-mobile-security-1.png', 'good condition, new samsung mobile.', '1'),
(112, 'Asus laptop', 'laptop', '2008357b7ef5038b42asus-zenbook-pro-ux501-review-_thumb800.jpg', 'brand new laptop', '1'),
(113, 'black tablet', 'tablet', '849657b7ef7ec87fdVodafone_Tablet_Prime_6_review_thumb800.jpg', 'this is low price tablet.', '1'),
(114, 'DSLR Camera', 'camera', '2909757b7efa46c84121008-DSLR-Cameras.jpg', 'its price is very cheap', '1'),
(115, '14'''' laptop', 'laptop', '1840157b7f01fc5b9alaptop_PNG5905.png', 'This is from now available in BD.', '1'),
(116, 'walton mobile', 'mobile', '2279057b7f05b698a2mobile.jpg', 'Gorila glass and price very cheap.', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(2) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`) VALUES
(1, 'mohon', '827ccb0eea8a706c4c34a16891f84e7b', 'mn.mohon@gmail.com', '1'),
(2, 'mohon', '827ccb0eea8a706c4c34a16891f84e7b', 'mn.mohoddn@gmail.com', '1'),
(3, 'mohon', '827ccb0eea8a706c4c34a16891f84e7b', 'khanr859@yahoo.com', '1'),
(4, 'mohon', '827ccb0eea8a706c4c34a16891f84e7b', 'emonkhan129@gmail.com', '1'),
(5, 'mohon', '827ccb0eea8a706c4c34a16891f84e7b', 'mn.mohoddn@gmail.com', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
