<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Description of photo_gallery_model
*
* @author Arnob
*/


class Products_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }




    public function user_login_data_check(){
    $username=$this->input->post('Username');
    $email=$this->input->post('Username');
    $password=md5($this->input->post('Password'));

    $attr=array(
        'email' => $email ,
        'password' =>$password
      );

    $result = $this->db->get_where('users', $attr);



    if($result->num_rows() == 1){
        $attr=array(
        'current_user_id' => $result->row(0)->id ,
        'current_user_email' => $result->row(1)->email ,
        'current_user_name' =>$username,
        //'current_user_picture' =>$result->row(2)->picture,
        'role'                 =>  $result->row(3)->role,
        //'isActive'             => $result->row(4)->isActive
      );
        //var_dump($attr); exit();
        $this->session->set_userdata($attr);
        return TRUE;
    }
    else{
      return FALSE;
    }
    }

      //user_login_data_check end


      //is_user_loged_in start
    public function is_user_loged_in(){
      return $this->session->userdata('current_user_id') != FALSE;
    }



    private $table_name = 'product'; 
    private $user_name = 'users'; 
    private $contactUs = 'contact_us';
    public function insert($data)
    {
        return $this->db->insert($this->table_name,$data);
    }

    public function contact_us_update($data,$where)
    {
         $this->db->where($where);
        return $this->db->update($this->contactUs,$data);
    }
   
    public function insert_batch($data)
    {
        return $this->db->insert_batch($this->table_name,$data);
    }
   
    public function select_where($select,$where)
    {
        $this->db->select($select);
        $this->db->where($where);
        $data = $this->db->get($this->table_name);
        if($data->num_rows()>0)
        {
            return $data->result();
        }
        else
        {
            return NULL;
        }
    }

    public function select_where_contact_us($select,$where)
    {
        $this->db->select($select);
        $this->db->where($where);
        $data = $this->db->get($this->contactUs);
        if($data->num_rows()>0)
        {
            return $data->result();
        }
        else
        {
            return NULL;
        }
    }

    public function select_all()
    {
        $this->db->where('status',1);
        $this->db->order_by('id','desc');
       $data = $this->db->get($this->table_name);
        
        if($data->num_rows()>0)
        {
            return $data->result();
        }
        else
        {
            return NULL;
        }
       
    }

    public function select_all_six()
    {
       $this->db->where('status',1);
        $this->db->order_by('id','desc');
        $this->db->limit(6);
        $data = $this->db->get($this->table_name);
        
        if($data->num_rows()>0)
        {
            return $data->result();
        }
        else
        {
            return NULL;
        }
     }




    public function contact_us()
    {

        //$this->db->where('status',1);
        //$this->db->order_by('id','desc');
        $data = $this->db->get($this->contactUs);
        
        if($data->num_rows()>0)
        {
            return $data->result();
        }
        else
        {
            return NULL;
        }
       
    }

    public function randomly_Select_product(){
        $result = mysql_query('SELECT COUNT(*) FROM product');
        $count = mysql_fetch_row($result);
        $id = rand(1, $count[0]);
        $result = mysql_query("SELECT * FROM product WHERE id=$id and status=1");
        if($result)
        {
            return $data->result();
        }
        else
        {
            return NULL;
        }

    }
   
    public function get_what($select = NULL, $where = NULL, $group_by = NULL, $S_limit = NULL, $l_limit = NULL, $order_by = 'DESC', $order_by_col = NULL) {
       if (!is_null($select)) {
           $this->db->select($select);
       }
       if (!is_null($where)) {
           $this->db->where($where);
       }
       if (!is_null($group_by)) {
           $this->db->group_by($group_by);
       }
       if (!is_null($order_by_col)) {
           $this->db->order_by($order_by_col, $order_by);
       }
       if (!is_null($S_limit) and ! is_null($l_limit)) {
           if ($S_limit === 0) {
               $this->db->limit($l_limit);
           } else {
               $this->db->limit($S_limit, $l_limit);
           }
       }        $data = $this->db->get($this->table_name);
       if ($data->num_rows() > 0) {
           return $data->result();
       } else {
           return NULL;
       }
   }
   
    public function update($data,$where)
    {
        $this->db->where($where);
        return $this->db->update($this->table_name,$data);
    }

     public function change_password(){
                $id = $this->session->userdata('current_user_id');
                $oldPassword = md5($this->input->post('password'));
                $newPassword = md5($this->input->post('newPassword'));
                $confirmPassword = md5($this->input->post('confirmPassword'));
                    //var_dump($email); exit();
            //$uname       = $this->input->post('name');
            
            //$query = "select * from users where uname ='{$uname}' or email ='{$email}' ";
            $this->db->select("*");
            $this->db->from('users');
            //$this->db->where('uname', $uname);
            //$this->db->or_where('email', $email);
            $this->db->where('password', $oldPassword);
            $this->db->where('id', $id);
            $count = $this->db->count_all_results();
            //var_dump($count); exit();
            if(!empty($newPassword)){
            
            if($count != '0' && ($newPassword==$confirmPassword)){

                
                $insert = "update users set password='{$newPassword}' where id={$id} and password='{$oldPassword}' ";
                $pass = $this->db->query($insert);
               // var_dump($insert); exit;
               
                 if($pass == true){
                    return true;
                
             }
                
                else{
                return FALSE;
            }   
        }
    }
}
   
    public function delete($where)
    {
        $this->db->where($where);
        return $this->db->delete($this->table_name);
    }





      public function record_count() {
       //  $this->db->where('status',1);
       // $data = $this->db->count_all($this->table_name);

       $query = $this->db->where('status', 1)->get('product');
      return $query->num_rows();

    }

    public function fetch_countries($limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->where('status', 1)->order_by('id ','desc')->get('product');

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }


   
    public function select_all_product_random()
    {
       $this->db->where('status',1);
        $this->db->order_by('RAND()');
        $this->db->limit(9);
        $data = $this->db->get($this->table_name);
        
        if($data->num_rows()>0)
        {
            return $data->result();
        }
        else
        {
            return NULL;
        }
     }

     public function select_all_email()
    {
        $query = $this->db->where('role', 1)->order_by('id ','asc')->get('users');
       //echo $this->db->last_query(); exit;
       return $query->result();
    }

}