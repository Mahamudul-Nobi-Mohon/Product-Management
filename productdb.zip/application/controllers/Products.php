<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Products extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Products_model');
        $this->load->library("pagination");
        $this->load->library("email");
        $this->load->library('upload');
        
    }
 

    public function index() {
       // $this->login();
        

        if($this->Products_model->is_user_loged_in()){
        
        $tempdata = $this->Products_model->select_all();

        if (is_null($tempdata)) {

            echo "<a href='add-category-view'>add category</a>";

            die();
        } else {
        
        $config = array();
        $config["base_url"] = base_url() . "Products/index";
        $config["total_rows"] = $this->Products_model->record_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["results"] = $this->Products_model->
           fetch_countries($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();
        
        $data['data'] = 'home';
        //$data['us'] = ""; 
        
        $this->load->view('dashboard_layout', $data);



             }
            }else{

                $tempdata = $this->Products_model->select_all_product_random();
             $i = 0;
            foreach ($tempdata as $value) {

                $categoryArray3[$i][0] = $value->title;
                $categoryArray3[$i][1] = $value->category;
                $categoryArray3[$i][2] = $value->description;
                $categoryArray3[$i][3] = $value->picture;
                $categoryArray3[$i++][4] = $value->id;
           
               }

               $data = array(
                    'show_all_random_products' => $categoryArray3
                    );
               $data['data'] = 'show_allproducts_random';
               $this->load->view('index2',$data);
        
      }
    }

    public function product_six_column(){
        
        
        $tempdata = $this->Products_model->select_all_six();
             $i = 0;
            foreach ($tempdata as $value) {

                $categoryArray3[$i][0] = $value->title;
                $categoryArray3[$i][1] = $value->category;
                $categoryArray3[$i][2] = $value->description;
                $categoryArray3[$i][3] = $value->picture;
                $categoryArray3[$i++][4] = $value->id;
           
               }

               $data = array(
                    'product_six' => $categoryArray3
                    );
               $data['data'] = 'updated_six_product';
               $this->load->view('index2',$data);
    }


    public function show_all_products(){

        

        $config = array();
        $config["base_url"] = base_url() . "Products/show_all_products";
        $config["total_rows"] = $this->Products_model->record_count();
        $config["per_page"] = 12;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["results"] = $this->Products_model->
           fetch_countries($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();
        
        $data = array(
                    'results' => $this->Products_model->
            fetch_countries($config["per_page"], $page),
            'links' => $this->pagination->create_links(),
            );
               $data['data'] = 'show_allproducts_for_user';
               $this->load->view('index2',$data);
    }

     


    public function about_us_page_view(){

        $contactUs = $this->Products_model->contact_us();
             $j = 0;
            foreach ($contactUs as $value) {

                $categoryArray2[$j][0] = $value->address;
                $categoryArray2[$j][1] = $value->phone;
                $categoryArray2[$j][2] = $value->email;
                $categoryArray2[$j][4] = $value->about_us;
                $categoryArray2[$j++][3] = $value->id;
               
                 }
             $data = array(
                    'contactUs' => $categoryArray2,
                    'data' => 'aboutus_for_user'
                    );
                     $this->load->view('index2',$data);
    }
    
    public function contact_us_page_view(){
        $contactUs = $this->Products_model->contact_us();
             $j = 0;
            foreach ($contactUs as $value) {

                $categoryArray2[$j][0] = $value->address;
                $categoryArray2[$j][1] = $value->phone;
                $categoryArray2[$j][2] = $value->email;
                $categoryArray2[$j][4] = $value->about_us;
                $categoryArray2[$j++][3] = $value->id;
               
                 }
             $data = array(
                    'contactUs' => $categoryArray2,
                    'data' => 'contact_us_user'
                    );
                     $this->load->view('index2',$data);
    }

    public function login(){
            $this->load->model('Products_model');
            if($this->Products_model->is_user_loged_in()){
                 redirect(site_url('category-list'));
            }

            else{
             $this->load->view('login-page');
            }
      }

      public function user_login_data_check(){
         $this->form_validation->set_rules('uname','User Name','trim|xss_clean|min_length[3]');
        $this->form_validation->set_rules('password','Password','trim|xss_clean');
        
        if($this->form_validation->run() == FALSE){
            $this->load->view('login-page');
        }

        else{
            $this->load->model('Products_model');
            $result=$this->Products_model->user_login_data_check();
                
            if($result){
                redirect(site_url('category-list'));
            }
            else{
                 $data['errorLogin'] ='Email or Password is Invalid.';
                 $this->load->view('login-page',$data);
            }
        }

    }

    public function logout(){
         //$this->load->model('Products_model');
           
        $this->session->unset_userdata('current_user_id');
        $this->session->unset_userdata('current_user_name');
        $this->session->sess_destroy();
        redirect('Products/?logout=success');
        //$this->load->view('login-page');
    }

    public function add() {
         
      if(!$this->Products_model->is_user_loged_in()){
           redirect('Products/index');
       }
        $data['data'] = 'add';
        $this->load->view('dashboard_layout', $data);
      }
    

    public function create() {
         //$this->login();
         if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }
          
         if (!($file_name = $_FILES["picture"]["type"]==("image/jpeg" or "image/jpg" or "image/gif" or "image/png"))) {
               $file_name = 'NULL';
            } 

          else{
            $file_name = uniqid(rand()).$_FILES["picture"]["name"];
            
            move_uploaded_file($_FILES["picture"]["tmp_name"], './images/'.$file_name);
          
            } 

        $title = $this->input->post('title');
        $category = $this->input->post('category');
        $description = $this->input->post('description');


        //Transfering data to Model
        $data = array(
            'title' => $title,
            'category' => $category,
            'description'=> $description,
            'picture' => $file_name,
            'status' => 1
        );
        
        if ($this->Products_model->insert($data)) {
            $this->session->set_flashdata('success', ' Created..');
            
            redirect(site_url('category-list'));
        } else {
            $this->session->set_flashdata('error', ' saved..');
            
            redirect(site_url('add-category-view'));
        }
      }
    

    // public function do_upload()
    //     {
    //             $upload_path="images/";  
    //     $uid='10'; //creare seperate folder for each user 
    //     $upPath=$upload_path."/".$uid;
    //     if(!file_exists($upPath)) 
    //     {
    //                mkdir($upPath, 0777, true);
    //     }
    //     $config = array(
    //     'upload_path' => $upPath,
    //     'allowed_types' => "gif|jpg|png|jpeg",
    //     'overwrite' => TRUE,
    //     'max_size' => "2048000", 
    //     'max_height' => "768",
    //     'max_width' => "1024"
    //     );
    //     $this->load->library('upload', $config);
    //     if(!$this->upload->do_upload('picture'))

    //     { 
    //         echo 'bye'; exit;
    //         $data['imageError'] =  $this->upload->display_errors();

    //     }
    //     else
    //     {
    //         echo 'hi'; exit;
    //         $imageDetailArray = $this->upload->data();
    //         $image =  $imageDetailArray['file_name'];
    //     }
    //     }


    public function delete($id) {
        
       if(!$this->Products_model->is_user_loged_in()){
        redirect('Products/index');
       }
           
         $id = $this->uri->segment(2);
        
        $data = array(
            
            'status' => 0
        );

        $where = array(
            'id' => $id
        );
        if ($this->Products_model->update($data, $where)) {
            $this->session->set_flashdata('success', ' Deleted..');
            redirect(site_url('category-list'));

           
        } else {
            $this->session->set_flashdata('error', ' Deleted..');
            
            redirect(site_url('add-category-view'));
        }
     }
   
   public function contact_us_update() {
         if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }
           
       
        //$id = 1;
        $phone = $this->input->post('phone');
        $email = $this->input->post('email');
        $address = $this->input->post('address');
        $about_us = $this->input->post('about_us');

        //Transfering data to Model
        $data = array(
            'phone' => $phone,
            'email' => $email,
            'address' => $address ,
            'about_us' => $about_us          
        );

        $where = array(
            'id' => 1
        );
        if ($this->Products_model->contact_us_update($data, $where)) {

            $this->session->set_flashdata('success', ' Updated..');
            
            redirect(site_url('category-list'));
        } else {
            $this->session->set_flashdata('error', ' Updated..');
            
            redirect(site_url('add-category-view'));
        }
      }

    public function change_password_page(){
        if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }
           
        $data['data'] = 'changePassword';
        $this->load->view('dashboard_layout', $data);
      }

      public function contact_us_page(){
        if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }
           
        $data['data'] = 'contact_us_edit';
        $this->load->view('dashboard_layout', $data);
      }
    
    

   public function change_password(){
                
               if(!$this->Products_model->is_user_loged_in()){
                redirect('Products/index');
       }
            

            if($this->Products_model->change_password()){

                $data['us'] = "Update successfully"; 
                
                $data['data'] = 'changePassword';
                $this->load->view('dashboard_layout',$data);
                    }
                else{
                    $data['error'] = "Not updated."; 
                
                    $data['data'] = 'changePassword';
                $this->load->view('dashboard_layout',$data);
                    }
                }
              

    public function edit($id) {
        // $this->login();
        if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }
           
        $id = $this->uri->segment(2);
        // if (!is_numeric($id)) {
        //     echo "Not a valid Id";
        //     redirect(site_url('category-list'));
        // }
        $select = array(
            '*'
        );
        $where = array(
            'id' => $id
        );
        $tempdata = $this->Products_model->select_where($select, $where);




        $getiddata[0] = $tempdata[0]->id;
        $getiddata[1] = $tempdata[0]->title;
        $getiddata[2] = $tempdata[0]->category;
        $getiddata[3] = $tempdata[0]->description;
       

        $data = array(
            'get_data' => $getiddata
        );

        $data['data'] = 'edit';
            
        $this->load->view('dashboard_layout', $data);
        
    }

    public function contact_us_edit($id) {
        // $this->login();
        if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }
           
        $id = 1;
        
        $select = array(
            '*'
        );
        $where = array(
            'id' => $id
        );
        $tempdata = $this->Products_model->select_where_contact_us($select, $where);




        $getiddata[0] = $tempdata[0]->id;
        $getiddata[1] = $tempdata[0]->phone;
        $getiddata[2] = $tempdata[0]->email;
        $getiddata[3] = $tempdata[0]->address;
        $getiddata[4] = $tempdata[0]->about_us;
       

        $data = array(
            'get_data' => $getiddata
        );

        $data['data'] = 'contact_us_edit';
            
        $this->load->view('dashboard_layout', $data);
        
    }



    public function moreInfo($id) {
        // $this->login();
        
        $id = $this->uri->segment(2);
        // if (!is_numeric($id)) {
        //     echo "Not a valid Id";
        //     redirect(site_url('category-list'));
        // }
        $select = array(
            '*'
        );
        $where = array(
            'id' => $id
        );
        $tempdata = $this->Products_model->select_where($select, $where);




        $getiddata[0] = $tempdata[0]->id;
        $getiddata[1] = $tempdata[0]->title;
        $getiddata[2] = $tempdata[0]->category;
        $getiddata[3] = $tempdata[0]->description;
        $getiddata[4] = $tempdata[0]->picture;


        $data = array(
            'get_data' => $getiddata
        );

        $data['data'] = 'moreinfo';
            
        $this->load->view('index', $data);
        
    }

    public function update() {
                // $this->login();
        if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }
           
        $config['upload_path']   = './images/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
         // $config['max_size']      = 100; 
         // $config['max_width']     = 1024; 
         // $config['max_height']    = 768;  
         $this->load->library('upload', $config);
            
         if ( ($config['allowed_types'] = 'gif|jpg|jpeg|png')) {
            $file_name = uniqid(rand()).$_FILES["picture"]["name"];
            move_uploaded_file($_FILES["picture"]["tmp_name"], './images/'.$file_name);
         
         } 


        $id = $this->input->post('id');
        $title = $this->input->post('title');
        $category = $this->input->post('category');
        $description = $this->input->post('description');


        //Transfering data to Model
        $data = array(
            'title' => $title,
            'category' => $category,
            'description' => $description,
            'picture' => $file_name
        );

        $where = array(
            'id' => $id
        );
        if ($this->Products_model->update($data, $where)) {

            $this->session->set_flashdata('success', ' Updated..');
            
            redirect(site_url('category-list'));
        } else {
            $this->session->set_flashdata('error', ' Updated..');
            
            redirect(site_url('add-category-view'));
        }
      }
    

    // public function view(){
    //     $this->load->view('home');
    // }




    public function example1() {

        if(!$this->Products_model->is_user_loged_in()){
            redirect('Products/index');
       }

        $config = array();
        $config["base_url"] = base_url() . "Products/example1";
        $config["total_rows"] = $this->Products_model->record_count();
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["results"] = $this->Products_model->
            fetch_countries($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();
        $data['data'] = "home";
        $this->load->view("dashboard_layout", $data);
    }


    public function send_email_accountability()
    {
      
            $this->load->library('email');
            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $message2 = $this->input->post('message');
           
            $this->email->initialize(array(
              'protocol' => 'smtp',
              'smtp_host' => 'ssl://smtp.mail.yahoo.com',
              'smtp_user' => 'emonkhan129@yahoo.com',
              'smtp_pass' => '3414710',
              'smtp_port' => '465',
              'crlf' => "\r\n",
              'newline' => "\r\n"
            ));

            $this->email->from('emonkhan129@yahoo.com', 'Your Name');
            $this->email->to('mn.mohon@gmail.com');
            $this->email->cc('khanr859@yahoo.com');
            $this->email->bcc('emonkhan129@yahoo.com');
            $this->email->subject($name);
            $this->email->message($message2);
            $this->email->send();
            $this->contact_us_page_view();
        
    }


    //database to email send 100% working tested by me
    /*
    public function send_email_accountability()
    {
            $this->load->library('email');
            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $message2 = $this->input->post('message');
           
            $this->email->initialize(array(
                  'protocol' => 'smtp',
                  'smtp_host' => 'ssl://smtp.mail.yahoo.com',
                  'smtp_user' => 'emonkhan129@yahoo.com',
                  'smtp_pass' => '3414710',
                  'smtp_port' => '465',
                  'crlf' => "\r\n",
                  'newline' => "\r\n"
            ));
             $tempdata = $this->Products_model->select_all_email();
             $i = 0;
            foreach ($tempdata as $value) {

                $categoryArray3[$i][0] = $value->email;
                $i++;
               
                $this->email->from('emonkhan129@yahoo.com', 'Company Email');
                $this->email->to($value->email.',');
                 $this->email->subject($name);
                $this->email->message($message2);
                $this->email->send();
            }
               $this->contact_us_page_view();
            
               
       } */


    
}


