<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="<?php echo base_url() ; ?>libs/img/favicon.png">

    <title>Product Management System</title>

    <!-- Bootstrap CSS -->    
    <link href="<?php echo base_url() ; ?>libs/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="<?php echo base_url() ; ?>libs/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="<?php echo base_url() ; ?>libs/css/elegant-icons-style.css" rel="stylesheet" />
    <link href="<?php echo base_url() ; ?>libs/css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="<?php echo base_url() ; ?>libs/assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="<?php echo base_url() ; ?>libs/assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="<?php echo base_url() ; ?>libs/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url() ; ?>libs/css/owl.carousel.css" type="text/css">
	<link href="<?php echo base_url() ; ?>libs/css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="<?php echo base_url() ; ?>libs/css/fullcalendar.css">
	<link href="<?php echo base_url() ; ?>libs/css/widgets.css" rel="stylesheet">
    <link href="<?php echo base_url() ; ?>libs/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url() ; ?>libs/css/style-responsive.css" rel="stylesheet" />
	<link href="<?php echo base_url() ; ?>libs/css/xcharts.min.css" rel=" stylesheet">	
	<link href="<?php echo base_url() ; ?>libs/css/jquery-ui-1.10.4.min.css" rel="stylesheet">
    <style>

#footer{
    display: table;
    text-align: center;
    margin-left: auto;
    margin-right: auto;
}
</style>

  </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
     
      
      <header class="header dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <!--logo start-->
             <?php if($this->session->userdata('role') == '1') { ?>
                                 
            <a href="#" class="logo">Admin <span class="lite">Panel &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</span></a>
            <a href="#" class="logo">Product  <span class="lite">Management </span>System</a>
            <?php } ?>
           

            <div class="nav search-row" id="top_menu">
                <!--  search form start -->
                <ul class="nav top-menu">                    
                    <li>
                        <form class="navbar-form" action="<?= site_url('search'); ?>" method="POST">
                            <!-- <input class="form-control" placeholder="Search" name="search" type="text"> -->
                        </form>
                    </li>                    
                </ul>
                <!--  search form end -->                
            </div>

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                
                        
                                
                                
                    
                                
                    <!-- alert notification end-->
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                 <!-- <img style="width:40px;height:40px" src="/ci-dashboard3-2-16/uploads/<?php //echo $this->session->userdata('current_user_picture');?>" /> -->
                            </span>
                            <span class="username"><?php echo $this->session->userdata('current_user_name');?></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            
                            
                            <li>
                                <a href="<?php echo site_url('change_password_page'); ?>"><i class="icon_key_alt"></i> Change Password</a>
                            </li>
                            
                            <li>
                                <a href="<?php echo site_url('logout');?>"><i class="icon_key_alt"></i> LogOut</a>
                            </li>
                            
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <!--header end-->

      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="active">
                      <a class="" href="<?php echo base_url('category-list') ; ?>">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span></a>
                       </li>
				              <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Products</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                         <?php if($this->session->userdata('role') == '1') { ?>
                                 
                          <li><a class="" href="<?php echo site_url('add-category-view'); ?>">Add Product</a></li>
                         <?php } ?>
                          <li><a class="" href="<?php echo base_url('category-list') ; ?>">All Products</a></li>
                          
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <!-- <span>Content Management</span> -->
                          <span>Settings</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                         <?php if($this->session->userdata('role') == '1') { ?>
                                 
                          
                          <li><a class="" href="<?php echo base_url('contact_us_page/1') ; ?>">Contact Page</a></li>
                          <?php } ?>
                      </ul>
                  </li>
                 
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside><br></br>
      
      <!--sidebar end-->
      
      <!--main content start-->
 <section id="main-content">
      <?php 
       if(isset($data)){
            $this->load->view($data) ; 
            }
            
        
      ?>
      <br><br><br><br>
      <!--main content end-->
  </section>

  <footer class="footer" style="background:#BDBDBD;">
          <div class="container" >
         
            <div class="copy text-center" style="margin-top:20px;">
               Copyright 2016 <a href='#'>Website</a>
            </div>
            
         </div>
      </footer>
  <!-- container section start -->

    <!-- javascripts -->
    <script src="<?php echo base_url() ; ?>libs/js/jquery.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/jquery-ui-1.10.4.min.js"></script>
    <script src="<?php echo base_url() ; ?>libs/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ; ?>libs/js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="<?php echo base_url() ; ?>libs/js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="<?php echo base_url() ; ?>libs/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url() ; ?>libs/js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="<?php echo base_url() ; ?>libs/assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="<?php echo base_url() ; ?>libs/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="<?php echo base_url() ; ?>libs/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="<?php echo base_url() ; ?>libs/js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <script src="<?php echo base_url() ; ?>libs/js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	<script src="<?php echo base_url() ; ?>libs/assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="<?php echo base_url() ; ?>libs/js/calendar-custom.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="<?php echo base_url() ; ?>libs/js/jquery.customSelect.min.js" ></script>
	<script src="<?php echo base_url() ; ?>libs/assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="<?php echo base_url() ; ?>libs/js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="<?php echo base_url() ; ?>libs/js/sparkline-chart.js"></script>
    <script src="<?php echo base_url() ; ?>libs/js/easy-pie-chart.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/xcharts.min.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/jquery.autosize.min.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/jquery.placeholder.min.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/gdp-data.js"></script>	
	<script src="<?php echo base_url() ; ?>libs/js/morris.min.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/sparklines.js"></script>	
	<script src="<?php echo base_url() ; ?>libs/js/charts.js"></script>
	<script src="<?php echo base_url() ; ?>libs/js/jquery.slimscroll.min.js"></script>
  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});

  </script>

  <script type='text/javascript'>
    
        $(document).ready(function(){

         $(".ajaxDelete").click(function(e){
           if(confirm('are you want to sure to delete ?')){
          e.preventDefault(); 
             var href = $(this).attr("href");
             var btn = this;

            $.ajax({
              type: "GET",
              url: href,
              success: function(response) {

              
                 $(btn).closest('tr').fadeOut("slow");
              
           }
        });
    }
    else {
        return false;
     }
       })
      });
</script>



  </body>
</html>


