<section id="services-section">
        <div class="wrap-pad">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 " data-scrollreveal="enter top and move 100px, wait 0.5s">
                    <div class="text-center">
                        <h1><i class="fa fa-check small-icons bk-color-green"></i>Latest Products</h1>
                       <!--  <p class="lead">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nec enim sapien. Aliquam erat volutpat.
                         Quisque eu ante at tortor imperdiet gravida nec sed turpis. Phasellus augue augue.                        
                        </p> -->
                    </div>
                </div>
                <!-- ./ Heading div-->
                <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 ">
                    <?php for ($i = 0; $i < sizeof($product_six); $i++) : ?>
                      <div class="col-md-4 col-sm-6" data-scrollreveal="enter left and move 100px, wait 0.6s">
                        <div class="text-center">
                            <h4><?php echo $product_six[$i][1] ?></h4>
                            
                            <img width="100" height="100" src="<?php echo base_url();?>images/<?php  echo $product_six[$i][3];?>">
                            <h2><?php echo $product_six[$i][0] ?></h2>
                            <p><?php echo $product_six[$i][2] ?></p>
                        </div>
                    </div>
                    <?php endfor ?>
                    
        </div>
    </section>