<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Free Bootstrap COLOI Multipurpose Template</title>
    <!--GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <!--BOOTSTRAP MAIN STYLES -->
    <link href="<?php echo base_url() ; ?>libs2/assets/css/bootstrap.min.css" rel="stylesheet" />
    <!--FONTAWESOME MAIN STYLE -->
    <link href="<?php echo base_url() ; ?>libs2/assets/css/font-awesome.min.css" rel="stylesheet" />
    <!--PRETTYPHOTO MAIN STYLE -->
    <link href="<?php echo base_url() ; ?>libs2/assets/css/prettyPhoto.css" rel="stylesheet" />
    <!--CUSTOM STYLE -->
    <link href="<?php echo base_url() ; ?>libs2/assets/css/style.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>

<body>

    <!--NAV SECTION -->
    <header id="header-nav" role="banner">
        <div id="navbar" class="navbar navbar-default">
            <div class="navbar-header">
                <a class="navbar-brand" href="#"><i class="fa fa-flask color-red"></i>Product Management</a>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse">
                <ul class="nav nav-pills flot-nav">
                    <li><a href="<?php echo base_url('category-list') ; ?>"><i class="fa fa-home color-red"></i> Home</a></li>
                    <li><a href="<?php echo base_url('about_us_page_view') ; ?>"><i class="fa fa-user color-brown"></i> About Us</a></li>
                    <li><a href="<?php echo base_url('product_six_column') ; ?>"><i class="fa fa-th color-green"></i> Latest Products</a></li>
                    <li><a href="<?php echo base_url('show_all_products') ; ?>"><i class="fa fa-th-list"></i> All Products</a></li>
                
                    <!-- <li><a href="#portfolio-section"><i class="fa fa-picture-o color-light-blue"></i> Products</a></li> -->
                    <li><a href="<?php echo base_url('contact_us_page_view') ; ?>"><i class="fa fa-comment"></i> Contact</a></li>
                </ul>
            </div>
        </div>
    </header>
    <!--END NAV SECTION -->
        <?php 
       if(isset($data)){
            $this->load->view($data) ; 
            }
            
        
      ?>
    
    <!--END CONTACT SECTION -->
    <!--FOOTER SECTION -->
    <footer id="footer">
        <div class="row">
            <div class="col-md-12  col-sm-12">
                &copy; 2016 www.yourdomain.com  |  All Rights Reserved
               
            </div>
        </div>
    </footer>
    <!--END FOOTER SECTION -->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY LIBRARY -->
    <script src="<?php echo base_url() ; ?>libs2/assets/js/jquery.js"></script>
    <!-- BOOTSTRAP SCRIPTS LIBRARY -->
    <script src="<?php echo base_url() ; ?>libs2/assets/js/bootstrap.min.js"></script>
    <!-- PRETTYPHOTO  SCRIPTS  LIBRARY-->
    <script src="<?php echo base_url() ; ?>libs2/assets/js/jquery.prettyPhoto.js"></script>
     <!-- SCROLL REVEL  SCRIPTS  LIBRARY-->
    <script src="<?php echo base_url() ; ?>libs2/assets/js/scrollReveal.js"></script>
    <!-- CUSTOM SCRIPT-->
    <script src="<?php echo base_url() ; ?>libs2/assets/scripts/custom.js"></script>
</body>
</html>
