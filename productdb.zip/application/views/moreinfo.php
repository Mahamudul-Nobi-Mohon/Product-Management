    <!-- Page Content -->
     <div class="col-lg-8">
            
    <div class="container">

        <!-- Heading Row -->
        
        <!-- /.row -->

        <hr>

        <!-- Call to Action Well -->
        <div class="row">
            <div class="col-lg-10">
                <!-- <div class="well text-center">
                    This is a well that is a great spot for a business tagline or phone number for easy access!
                </div> -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <div class="col-lg-12">
          
     <?php if($this->session->userdata('role') != '1') { ?>
                 <div class="row">
           
                <div class="col-md-4">

                <tr>

                    <h2><td>Title: <?php echo $get_data[1]; ?></td>
                    </h2>
                     <td>Picture: <img src="<?php echo base_url();?>images/<?php echo $get_data[4] ;?>" width="400" height="400">  </td>
                  
                    <h2><td>Category: <?php echo $get_data[2] ;?></td></h2>
                    <p><p><td>Description:    <?php echo $get_data[3] ;?></td></p>
                     
                  </tr>
                    </div>
                
            <!-- /.col-md-4 -->
            
            <!-- /.col-md-4 -->
        
      </div>
            
        <?php } ?>
        </div>
    </div>

   