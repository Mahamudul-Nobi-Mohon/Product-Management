<br></br>
<div class="container">
<div class="row">
  <div class="col-md-12">
   </div>
   <?php echo form_open_multipart('Products/contact_us_update');?> 
    
      <form action = "" method = "">
        <?php if(isset($us)){ ?>         
                            <pre style="color:green"><?php echo "Password Changed Successfully."; ?></pre>
                          <?php
                             }
                             if(isset($error)){ ?>
                               <pre style="color:red"><?php echo "Password Not Changed."; ?></pre>
                        
                           <?php  }
                           ?>
      <div class="col-lg-6">
      <div class="form-group">
        <label for="InputName">Mobile Number</label>
        <div class="input-group">
          <input type="text" class="form-control" name="phone" id="InputName" placeholder="Product title" value="<?php echo $get_data[1] ;?>" required>
          <span class="input-group-addon"></span></div>
      </div>
      <div class="form-group">
        <label for="InputEmail">Email</label>
        <div class="input-group">
          <input type="text" class="form-control" id="InputEmail" name="email" placeholder="Product Category" value="<?php echo $get_data[2] ;?>"   >
          <span class="input-group-addon"></span></div>
      </div>
      <div class="form-group">
        <label for="InputMessage">Address</label>
        <div class="input-group"
>
          <textarea name="address" id="InputMessage" class="form-control" rows="5" ><?php echo $get_data[3] ;?></textarea>
          <span class="input-group-addon"></span></div>
      </div>

      <div class="form-group">
        <label for="InputMessage">About us</label>
        <div class="input-group"
>
          <textarea name="about_us" id="InputMessage" class="form-control" rows="5" ><?php echo $get_data[4] ;?></textarea>
          <span class="input-group-addon"></span></div>
      </div>
      
      <input type="submit" name="submit" id="submit" value="Submit" class="btn btn-info pull-right">
    </div>
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
   <input type="hidden" name="id" value="<?php echo $get_data[0] ;?>">
  </form>
  <hr class="featurette-divider hidden-lg">
  
</div>

</div>