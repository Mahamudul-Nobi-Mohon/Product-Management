<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="<?php echo base_url() ?>libs/shortcut icon" href="libs/img/favicon.png">

    <title>Product management system</title>

    <!-- Bootstrap CSS -->    
    <link href="<?php echo base_url() ?>libs/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="<?php echo base_url() ?>libs/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="<?php echo base_url() ?>libs/css/elegant-icons-style.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>libs/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="<?php echo base_url() ?>libs/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>libs/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

  <body class="login-img3-body">

    <div class="container">
    		           
    <div class="login-form">
    
      <?php echo form_open('Products/user_login_data_check');?>        
        <div class="login-wrap">
        
        <?php if(validation_errors()){ ?>
        <div class="alert">

        		<pre style="color:red"><?php echo validation_errors(); ?></pre>
       	</div>
    			<?php
         		 }
         		 if(isset($errorLogin)) { 
         		 ?>
        <div class="alert">

        		<pre style="color:red"><?php echo 'Username or Password is Invalid.'; ?></pre>
        </div>
         		<?php }
       		 ?>
       		 <p>Login Me...</p>
            <p class="login-img"><i class="icon_lock_alt"></i></p>
            <div class="input-group">
            
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <?php 
              		$username=array(
              			'id'   =>   'Username_input',
              			'class' =>    'form-control',
              			'name' =>   'Username',
              			'required' => 'required',
                    'placeholder' => ' please type your email'
              			);
              		echo form_input($username);
              ?>
              <!-- <input type="text" class="form-control" placeholder="Username" autofocus> -->
            </div>
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <?php 
              		$password=array(
              			'id'   =>   'Username-input',
              			'class' =>    'form-control',
              			'name' =>   'Password',
              			//'type' => 'password' ,
              			'required' => 'required',
                    'placeholder' => ' please type your password'
              			);
              		echo form_password($password);
              ?>
                <!-- <input type="password" class="form-control" placeholder="Password"> -->
            </div>
            <!-- <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
                <span class="pull-right"> <a href="#"> Forgot Password?</a></span>
            </label> -->
            <button class="btn btn-primary btn-lg btn-block" type="submit">Login</button>
            <!-- <button class="btn btn-info btn-lg btn-block" type="submit">Signup</button> -->
        </div>
      <?php echo form_close() ;?>
</div>
    </div>


  </body>
</html>
