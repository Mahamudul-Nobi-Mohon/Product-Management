<br></br><br></br>
<div class="container">
<div class="row">
  <div class="col-md-12">
   </div>
   <?php echo form_open_multipart('Products/create');?> 
    
      <form action = "" method = "">
      <div class="col-lg-6">
      <div class="form-group">
        <label for="InputName">Title</label>
        <div class="input-group">
          <input type="text" class="form-control" name="title" id="InputName" placeholder="Product title" required>
          <span class="input-group-addon"></span></div>
      </div>
      <div class="form-group">
        <label for="InputEmail">Category</label>
        <div class="input-group">
          <input type="text" class="form-control" id="InputEmail" name="category" placeholder="Product Category"   >
          <span class="input-group-addon"></span></div>
      </div>
      <div class="form-group">
        <label for="InputMessage">Description</label>
        <div class="input-group"
>
          <textarea name="description" id="InputMessage" class="form-control" rows="5" ></textarea>
          <span class="input-group-addon"></span></div>
      </div>
      <div class="form-group">
        <label for="InputReal">Picture</label>
        <div class="input-group">
          <input type="file" class="form-control" name="picture" id="InputReal" >
          <span class="input-group-addon"></span></div>
      </div>
      <input type="submit" name="submit" id="submit" value="Submit" class="btn btn-info pull-right">
    </div>
  </form>
  <hr class="featurette-divider hidden-lg">
  
</div>

</div>