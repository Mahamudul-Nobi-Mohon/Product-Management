
<br/><br/><br/><br/>
<div class="col-lg-12">
                      <!--Project Activity start-->

                      <section class="panel">
                          <div class="panel-body progress-panel">
                            <div class="row">
                              <div class="col-lg-8 task-progress pull-left">
                                  <h1>View All Users</h1>                                  
                              </div>
                              
                            </div>
                          </div>
                          <table class="table table-hover personal-task " style="">
                              <thead>
                              <tr>
                                  <th style="color:green">Full Name</th>
                                  <th style="color:green">User Name</th>
                                  <th style="color:green">Email</th>
                                  <th style="color:green">Role</th>
                                  <th style="color:green">Action</th>
                              </tr>
                              <tr>                            
                              </thead>
                              <tbody>
                                <?php for ($i = 0; $i < sizeof($search); $i++) : ?>
                                   <?php $i + 1; ?>
                              <tr id=" <?= $search[$i][0]; ?>">
                                  <td><?= $search[$i][1].' '. $search[$i][2]; ?></td>
                                  <td>
                                      <?= $search[$i][3]; ?>
                                  </td>
                                  <td>
                                      <?= $search[$i][4]; ?>
                                  </td>
                                  <td>
                                    Admin
                                  </td>
                                  <td>
                                    <?php if($this->session->userdata('current_user_id') !=  $search[$i][0]) { ?>
                                    <a  class="ajaxDelete"  id="<?php echo base_url() ; ?>" href="<?php echo base_url() ; ?>users/user_delete/<?php echo $search[$i][0] ?>"><img title="Click ForDelete" src='<?php echo base_url() ; ?>libs/delete.png' style="height:30px; width:30px;"></a>
                                  
                                  <?php } ?>
                                   <a href="<?php echo base_url() ; ?>users/edit_user/<?php echo $search[$i][0] ?>"><img title="Click For Edit" src='<?php echo base_url() ; ?>libs/edit.png' style="height:30px; width:30px;"></a>
                                   <?php if($search[$i][7] != '1') { ?>
                                   <a href="<?php echo base_url() ; ?>users/ActiveAccount/<?php echo $search[$i][0] ?>"><img title="Click For Active Account" src='<?php echo base_url() ; ?>libs/deactiveAccount.jpg' style="height:30px; width:30px;"></a>
                                   <?php } if($search[$i][7] == '1') { ?>
                                   <a href="<?php echo base_url() ; ?>users/DeActiveAccount/<?php echo $search[$i][0]?>"><img title="Click For DeActive Account" src='<?php echo base_url() ; ?>libs/activeAccount.jpg' style="height:30px; width:30px;"></a>
                                   <?php } ?>

                                   </td>
                              </tr>
                              <tr>  
                              <?php endfor;
                             // endif;
                              ?>                          
                              </tbody>
                              
                          </table>
                         
                      </section>
                      <!--Project Activity end-->
                  </div>
              </div><br><br>