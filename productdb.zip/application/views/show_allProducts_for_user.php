
    <section >
        <div class="wrap-pad">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 " data-scrollreveal="enter top and move 100px, wait 0.5s">
                    <div class="text-center">
                        <h1><i class="fa fa-picture-o small-icons bk-color-light-blue"></i>Products</h1>
                        <!-- <p class="lead">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nec enim sapien. Aliquam erat volutpat.
                         Quisque eu ante at tortor imperdiet gravida nec sed turpis. Phasellus augue augue.                        
                        </p> -->
                    </div>
                </div>
                <!-- ./ Heading div-->
              
                <div class="col-md-10 col-md-offset-1 col-sm-12" data-scrollreveal="enter right and move 100px">
                    <?php //for ($i = 0; $i < sizeof($categories); $i++) : ?>
                    <p><?php echo $links; ?></p>
                   <?php foreach($results as $data) { ?>
                    
                    <ul class="portfolio-items col-3">
                        <li class="portfolio-item ">
                            <div class="item-main">
                                <h2><?php  echo $data->category?></h2>
                                <div class="portfolio-image">
                                    <img width="100" height="100" src="<?php echo base_url();?>images/<?php  echo $data->picture;?>">
                                         <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="<?php echo base_url() ; ?>images/<?php  echo $data->picture; ?>"><i class=" fa fa-eye"></i></a>
                                        <p>To display details, click on the link <a href="#" onClick="document.getElementById('shadowing').style.display='block';
                          document.getElementById('box').style.display='block';">open</a> </div>
                                </div>
                                <h5><?php  echo $data->title?></h5>
                            </div>
                        </li>
                       
                        
                    </ul>
                    <div id="shadowing"></div>
                    <div id="box">
                       <span id="boxclose" onClick="document.getElementById('box').style.display='none';
                       document.getElementById('shadowing').style.display='none'"><b>X</b> </span>
                 <div id="boxcontent">    
                    <?php  echo $data->description?>   
                    </div>
                 </div>

                <style type="text/css">
                #shadowing{display: none;position: fixed;top: 0%;left: 0%;width: 100%;height: 100%; background-color: #CCA; z-index:10;    opacity:0.5; filter: alpha(opacity=50);}
                #box {display: none;position: fixed;top: 20%;left: 20%;width: 60%;height: 60%;max-height:400px;padding: 0; margin:0;border: 1px solid black;background-color: white;z-index:11; overflow: hidden;}   
                #boxclose{float:right;position:absolute; top: 0; right: 0px; background-image:url(images/close.gif);background-repeat:no-repeat;    background-color:#CCC; border:1px solid black; width:20px;height:20px;margin-right:0px;}
                #boxcontent{position:absolute;top:23px;left:0;right:0;bottom:0;margin:0 0 0 0;padding: 8px;overflow: auto;width:100%;height:100%;   overflow:hidden;}
                </style>
                <?php } ?>

                
                       

                </div>
                <!-- ./ Content div-->
            </div>
            <p><?php echo $links; ?></p>
        </div>
                
                 
    </section>

    