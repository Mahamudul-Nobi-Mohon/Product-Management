<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method


*/
///ProductsController
//$route['update/:any'] = 'users/updateUser';
//search
$route['new-category'] = 'Products/create';
$route['category-update'] = 'Products/update';
$route['category-delete/:num'] = 'Products/delete/';


$route['category-list'] = 'Products/index';
$route['add-category-view'] = 'Products/add';


$route['category-edit/:num'] =  'Products/edit/' ;
$route['more-info/:num'] =  'Products/moreInfo/' ;

$route['contact_us_page/1'] =  'Products/contact_us_edit/1' ;





 $route['default_controller'] = 'Products/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['logout'] = 'Products/logout';
$route['change_password_page'] = 'Products/change_password_page';
$route['show_all_products'] = 'Products/show_all_products';
$route['product_six_column'] = 'Products/product_six_column';
$route['about_us_page_view'] = 'Products/about_us_page_view';
$route['contact_us_page_view'] = 'Products/contact_us_page_view';
$route['email'] = 'Email_Controller';



